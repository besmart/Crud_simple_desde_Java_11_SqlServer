//
//   Author: Ing.Carlos Alberto Diaz Raigosa
//   Correo: aliadas233@gmail.com
//   Contacto: 3045918188-Medellín-Colombia
//
import java.util.Scanner;

public class Principal {

    private static Scanner scanner = new Scanner(System.in);
    private static boolean existe = false;
    private static Long Id;
    private static String Usuario;
    private static String Clave;

    public static void main(String[] args) {

        DBManager.iniConnection();
        boolean Noexiste = false;
        int opc;
        do {
            System.out.println("1. Consulta Usuarios");
            System.out.println("2. Crear Usuario");
            System.out.println("3. Actualizar Usuario");
            System.out.println("4. Eliminar Usuario");
            System.out.println("5. Ver persona");
            System.out.println("6. Crear persona");
            System.out.println("7. Editar persona");
            System.out.println("8. Eliminar persona");
            System.out.println("9. Salir");
            opc = scanner.nextInt();
            switch (opc) {
                case 1:
                    consultaLogin();
                    break;
                case 2:
                    Noexiste = validarLogin(existe);
                        if (!Noexiste) {
                            crearLogin();
                            System.out.println("Ingreso exitoso...");
                        } else {
                            System.out.println("Usuario y/o Clave YA existe...");
                        }
                        break;
                case 3:
                    Noexiste = validarLogin(existe);
                        if (Noexiste) {
                            actualizarLogin();
                            System.out.println("Actualización exitosa...");
                        } else {
                            System.out.println("Usuario y/o Clave NO existe...");
                        }
                    break;
                case 4:
                    Noexiste = validarLogin(existe);
                    if (Noexiste) {
                        eliminarLogin();
                        System.out.println("Eliminación exitosa...");
                    } else {
                        System.out.println("Usuario y/o Clave NO existe...");
                    }
                    break;
                case 5:
                    verPersonas();
                    break;
                case 6:
                  Noexiste = validarPersona(existe);
                    if (!Noexiste) {
                        crearPersonas();
                        System.out.println("Ingreso exitoso...");
                    }  else {
                       System.out.println("Registro ya existe...");
                    }
                    break;
                case 7:
                    Noexiste = validarPersona(existe);
                    if (Noexiste) {
                        editarPersonas();
                        System.out.println("Actualización exitosa...");
                    }  else {
                        System.out.println("Registro No existe...");
                    }
                    break;
                case 8:
                    Noexiste = validarPersona(existe);
                    if (Noexiste) {
                        eliminarPersonas();
                        System.out.println("Eliminación exitosa...");
                    }  else {
                        System.out.println("Registro No existe...");
                    }
                    break;
                default:
                    break;
            }
        } while (opc != 9);
    }

    public static void verPersonas() {
        DBManager.consultaPersona();
    }
    public static void crearPersonas() {
        System.out.println("Ingrese Nombres");
        scanner.nextLine();
        String nombres = scanner.nextLine();

        System.out.println("Ingrese Apellidos");
        String apellidos = scanner.nextLine();

        System.out.println("Ingrese Edad");
        int edad = scanner.nextInt();

        System.out.println("Ingrese Correo");
        String correo = scanner.nextLine();

        DBManager.insertPersona(Id.intValue(), nombres, apellidos, edad, correo );
    }

    public static void editarPersonas() {
        System.out.println("Ingrese Nombres");
        scanner.nextLine();
        String nombres = scanner.nextLine();

        System.out.println("Ingrese Apellidos");
        String apellidos = scanner.nextLine();

        System.out.println("Ingrese Edad");
        int edad = scanner.nextInt();

        System.out.println("Ingrese Correo");
        String correo = scanner.nextLine();

        DBManager.updatePersona(Id.intValue(), nombres, apellidos, edad, correo);
    }

    public static void eliminarPersonas() {
        DBManager.eliminarPersonas(Id.intValue());
    }

    public static boolean validarPersona(boolean Siexiste) {
        Id = Long.valueOf(0);
        System.out.println("Ingrese Identificación");
        int id = scanner.nextInt();
        Id = Long.valueOf(id);
        Siexiste = DBManager.validaExistencia(id, existe);

        final boolean siexiste = Siexiste;
        return siexiste;
    }

    public static void consultaLogin() {
        DBManager.consultaLogin();
    }

    public static void crearLogin() {

        System.out.println("Ingrese Identificacion");
        int id = scanner.nextInt();
        Id = Long.valueOf(id);


        DBManager.insertLogin(Usuario, Clave, Id.intValue());
    }

    public static void actualizarLogin() {

        System.out.println("Actualice Identificacion");
        int id = scanner.nextInt();
        Id = Long.valueOf(id);

        DBManager.updateLogin(Usuario, Clave, Id.intValue());
    }

    public static void eliminarLogin() {
        int id = 0;
        Id = DBManager.consultaLoginExistencia(Usuario, Clave, Long.valueOf(id));
        DBManager.eliminarLogin(Usuario, Clave, Id);
        DBManager.eliminarPersonas(Id.intValue());
    }

    public static boolean validarLogin(boolean Siexiste) {
        limpiarVariables();

        System.out.println("Entre Usuario");
        scanner.nextLine();
        Usuario = scanner.nextLine();

        System.out.println("Entre Clave");
        Clave = scanner.nextLine();

        Siexiste = DBManager.validaUsuario(Usuario, Clave, existe);

        final boolean siexiste = Siexiste;
        return siexiste;
    }

    public static void limpiarVariables(){
        Usuario = "";
        Clave = "";
    }

}