//
//   Author: Ing.Carlos Alberto Diaz Raigosa
//   Correo: aliadas233@gmail.com
//   Contacto: 3045918188-Medellín-Colombia
//
import java.util.Scanner;

public class Principal {

    private static Scanner scanner = new Scanner(System.in);
    private static boolean existe = false;
    private static Long Id;

    public static void main(String[] args) {

        DBManager.iniConnection();
        boolean Noexiste = false;
        int opc;
        do {
            System.out.println("1. Ver persona");
            System.out.println("2. Crear persona");
            System.out.println("3. Editar persona");
            System.out.println("4. Eliminar persona");
            System.out.println("5. Salir");
            opc = scanner.nextInt();
            switch (opc) {
                case 1:
                    verPersonas();
                    break;
                case 2:

                  Noexiste = validarPersona(existe);
                    if (!Noexiste) {
                        crearPersonas();
                        System.out.println("Ingreso exitoso...");
                    }  else {
                       System.out.println("Registro ya existe...");
                    }
                    break;
                case 3:
                    Noexiste = validarPersona(existe);
                    if (Noexiste) {
                        editarPersonas();
                        System.out.println("Actualización exitosa...");
                    }  else {
                        System.out.println("Registro No existe...");
                    }
                    break;
                case 4:
                    Noexiste = validarPersona(existe);
                    if (Noexiste) {
                        eliminarPersonas();
                        System.out.println("Eliminación exitosa...");
                    }  else {
                        System.out.println("Registro No existe...");
                    }
                    break;
                default:
                    break;
            }
        } while (opc != 5);
    }

    public static void verPersonas() {
        DBManager.consultaPersona();
    }

    public static void crearPersonas() {
        System.out.println("Ingrese Nombres");
        scanner.nextLine();
        String nombres = scanner.nextLine();

        System.out.println("Ingrese Apellidos");
        String apellidos = scanner.nextLine();

        System.out.println("Ingrese Edad");
        int edad = scanner.nextInt();

        DBManager.insertPersona(Id.intValue(), nombres, apellidos, edad);
    }

    public static void editarPersonas() {
        System.out.println("Ingrese Nombres");
        scanner.nextLine();
        String nombres = scanner.nextLine();

        System.out.println("Ingrese Apellidos");
        String apellidos = scanner.nextLine();

        System.out.println("Ingrese Edad");
        int edad = scanner.nextInt();

        DBManager.updatePersona(Id.intValue(), nombres, apellidos, edad);
    }

    public static void eliminarPersonas() {
        DBManager.eliminarPersonas(Id.intValue());
    }

    public static boolean validarPersona(boolean Siexiste) {
        Id = Long.valueOf(0);
        System.out.println("Ingrese Identificación");
        int id = scanner.nextInt();
        Id = Long.valueOf(id);
        Siexiste = DBManager.validaExistencia(id, existe);

        final boolean siexiste = Siexiste;
        return siexiste;
    }
}