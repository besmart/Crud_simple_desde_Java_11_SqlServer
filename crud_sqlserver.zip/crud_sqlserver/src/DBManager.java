import java.sql.*;
public class DBManager {

    private static Connection connection;
    private static boolean existe;
    public static void iniConnection() {
        try {
            connection = DriverManager.getConnection("jdbc:sqlserver://localhost;encrypt=true;database=MyBase;integratedSecurity=true;TrustServerCertificate=True;");
            System.out.println("conectado con exito");
        } catch (Exception e) {
            System.out.println("getMessage()");
        }
    }

    public static void insertPersona(int Identificacion_Persona, String Nombres_Persona, String Apellidos_Persona, int Edad_Persona) {
        try {
            PreparedStatement stmn = connection.prepareStatement("INSERT INTO dbo.persona (Identificacion_Persona, Nombres_Persona, Apellidos_Persona, Edad_Persona) VALUES (?, ?, ?, ?)");
            stmn.setInt(1, Identificacion_Persona);
            stmn.setString(2, Nombres_Persona);
            stmn.setString(3, Apellidos_Persona);
            stmn.setInt(4, Edad_Persona);
            stmn.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public static void updatePersona(int id, String nombres, String apellidos, int edad) {
        try {
            PreparedStatement stmn = connection.prepareStatement("UPDATE dbo.persona SET Nombres_Persona =" + "'" +
                                                                      nombres + "'" +", Apellidos_Persona =" + "'" + apellidos +
                                                                      "'" + ", Edad_Persona = " + edad +
                                                                      " WHERE Identificacion_Persona =" + id);
            stmn.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void consultaPersona() {
        try {
          PreparedStatement stmn = connection.prepareStatement("SELECT *  FROM dbo.persona");
          ResultSet rs = stmn.executeQuery();
          System.out.println("Identifiaccion | Nombres      | Apellidos     | Edad");
          if (rs != null) {
             while (rs.next()){
                 long id = rs.getLong("Identificacion_Persona");
                 String nombres = rs.getString("Nombres_Persona");
                 String apellidos = rs.getString("Apellidos_Persona");
                 long edad = rs.getLong("Edad_Persona");

                 System.out.println(id + "     \t" + nombres + " \t" + apellidos + " \t" + edad);
              }
          }
        } catch (SQLException e) {
            e.getNextException();
        }
    }

    public static void eliminarPersonas(int id) {
        try {
            PreparedStatement stmn = connection.prepareStatement("DELETE FROM dbo.persona" +
                                                                     " WHERE Identificacion_Persona =" + id);
            stmn.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static boolean validaExistencia(int id, boolean existe) {
        long Id = 0;
        try {
            PreparedStatement stmn =   connection.prepareStatement("SELECT * FROM dbo.persona" +
                    " WHERE Identificacion_Persona = " + id);
            ResultSet rs = stmn.executeQuery();

            if (rs != null) {
                while (rs.next()) {
                    Id = rs.getInt("Identificacion_Persona");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        if (Id == id) {
            existe = true;
        }
        return existe;
    }
}
