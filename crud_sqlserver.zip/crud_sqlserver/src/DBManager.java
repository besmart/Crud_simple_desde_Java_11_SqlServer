//
//   Author: Ing.Carlos Alberto Diaz Raigosa
//   Correo: aliadas233@gmail.com
//   Contacto: 3045918188-Medellín-Colombia
//
import java.sql.*;
public class DBManager {

    private static Connection connection;
    private static boolean existe;
    public static void iniConnection() {
        try {
            connection = DriverManager.getConnection("jdbc:sqlserver://localhost;encrypt=true;database=MyBase;integratedSecurity=true;TrustServerCertificate=True;");
            System.out.println("conectado con exito");
        } catch (Exception e) {
            System.out.println("getMessage()");
        }
    }

    public static void insertPersona(int Identificacion_Persona, String Nombres_Persona, String Apellidos_Persona, int Edad_Persona, String Correo_Electronico) {
        try {
            PreparedStatement stmn = connection.prepareStatement("INSERT INTO dbo.persona (Identificacion_Persona, Nombres_Persona, Apellidos_Persona, Edad_Persona, Correo_Electronico) VALUES (?, ?, ?, ?, ?)");
            stmn.setInt(1, Identificacion_Persona);
            stmn.setString(2, Nombres_Persona);
            stmn.setString(3, Apellidos_Persona);
            stmn.setInt(4, Edad_Persona);
            stmn.setString(5,Correo_Electronico);
            stmn.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public static void updatePersona(int id, String nombres, String apellidos, int edad, String correo) {
        try {
            PreparedStatement stmn = connection.prepareStatement("UPDATE dbo.persona SET Nombres_Persona =" + "'" +
                                                                      nombres + "'" +", Apellidos_Persona =" + "'" + apellidos +
                                                                      "'" + ", Edad_Persona = " + edad +
                                                                      ", Correo_Electronico = " + "'" + correo + "'" +
                                                                      " WHERE Identificacion_Persona = " + id);
            stmn.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void consultaPersona() {
        try {
          PreparedStatement stmn = connection.prepareStatement("SELECT *  FROM dbo.persona");
          ResultSet rs = stmn.executeQuery();
          System.out.println("Identifiaccion | Nombres      | Apellidos     | Edad  | Correo");
          if (rs != null) {
             while (rs.next()){
                 long id = rs.getLong("Identificacion_Persona");
                 String nombres = rs.getString("Nombres_Persona");
                 String apellidos = rs.getString("Apellidos_Persona");
                 String  correo = rs.getString("Correo_Electronico");
                 long edad = rs.getLong("Edad_Persona");

                 System.out.println(id + "     \t" + nombres + " \t" + apellidos + " \t" + edad +  "\t" + correo);
              }
          }
        } catch (SQLException e) {
            e.getNextException();
        }
    }

    public static void eliminarPersonas(int id) {
        try {
            PreparedStatement stmn = connection.prepareStatement("DELETE FROM dbo.persona" +
                    " WHERE Identificacion_Persona =" + id);
            stmn.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static boolean validaExistencia(int id, boolean existe) {
        long Id = 0;
        try {
            PreparedStatement stmn =   connection.prepareStatement("SELECT * FROM dbo.persona" +
                    " WHERE Identificacion_Persona = " + id);
            ResultSet rs = stmn.executeQuery();

            if (rs != null) {
                while (rs.next()) {
                    Id = rs.getInt("Identificacion_Persona");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        if (Id == id) {
            existe = true;
        }
        return existe;
    }

    public static boolean validaUsuario(String usuario, String clave, boolean existe) {
        String Wusuario = "";
        String Wclave = "";

        try {
            PreparedStatement stmn =   connection.prepareStatement("SELECT * FROM dbo.Login" +
                    " WHERE Usuario_Login = " + "'" + usuario + "'" + " AND " + "Clave_Login = " + "'" + clave + "'");
            ResultSet rs = stmn.executeQuery();

            if (rs != null) {
                while (rs.next()) {
                    Wusuario = rs.getString("Usuario_Login");
                    Wclave = rs.getString("Clave_Login");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        if (Wusuario.equals(usuario) && Wclave.equals(clave))  {
            existe = true;
        }
        return existe;
    }
    public static void consultaLogin() {
        try {
            PreparedStatement stmn = connection.prepareStatement("SELECT *  FROM dbo.login");
            ResultSet rs = stmn.executeQuery();
            System.out.println("Usuario Login | Clave Login      | Identificacion_Login");
            if (rs != null) {
                while (rs.next()){
                    String usuario = rs.getString("Usuario_login");
                    String clave = rs.getString("Clave_Login");
                    int id = rs.getInt("Identificacion_Login");

                    System.out.println(usuario + "       \t" + clave + "     \t"	+ id );
                }
            }
        } catch (SQLException e) {
            e.getNextException();
        }
    }

    public static void insertLogin(String Usuario_Login, String Clave_Login, int Identificacion_Login) {
        try {
            PreparedStatement stmn = connection.prepareStatement("INSERT INTO dbo.Login (Usuario_Login, Clave_Login, Identificacion_Login) VALUES (?, ?, ?)");
            stmn.setString(1, Usuario_Login);
            stmn.setString(2, Clave_Login);
            stmn.setInt(3, Identificacion_Login);
            stmn.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public static void updateLogin(String WUsuario, String WClave, int id ) {
        try {
            PreparedStatement stmn = connection.prepareStatement("UPDATE dbo.Login SET Identificacion_Login =" +
                    id + " WHERE Usuario_Login =" + "'" + WUsuario + "'" + " AND " + "Clave_Login =" + "'" + WClave +"'");

            stmn.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void eliminarLogin(String WUsuario, String WClave, Long id) {
        if (id > 0 ) {
            try {
                PreparedStatement stmn = connection.prepareStatement("DELETE FROM dbo.Login" +
                               " WHERE Usuario_Login =" + "'" + WUsuario + "'" + " AND " + "Clave_Login =" + "'" + WClave +"'" +
                               " AND "  + "Identificacion_Login = "  + id );

                stmn.execute();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static Long consultaLoginExistencia(String usuario, String clave, Long id) {
        String Wusuario = "";
        String Wclave = "";
        id = Long.valueOf(0);
        try {
            PreparedStatement stmn = connection.prepareStatement("SELECT *  FROM dbo.login" +
                                     " WHERE Usuario_login = " + "'" + usuario + "'" + " AND " + "Clave_Login = " + "'" + clave + "'");
            ResultSet rs = stmn.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    Wusuario = rs.getString("Usuario_login");
                    Wclave = rs.getString("Clave_Login");
                    id = Long.valueOf(rs.getInt("Identificacion_Login"));
                }
            }
        } catch (SQLException e) {
            e.getNextException();
        }
        if (Wusuario.equals(usuario) && Wclave.equals(clave))  {
            return  id;
        } else {
            id = Long.valueOf(0);
        }
        return id;
    }
}
